//>>built
define("dijit/_editor/nls/fr/LinkDialog",({createLinkTitle:"Propriétés du lien",insertImageTitle:"Propriétés de l'image",url:"URL :",text:"Description :",target:"Cible :",set:"Définir",currentWindow:"Fenêtre actuelle",parentWindow:"Fenêtre parent",topWindow:"Fenêtre supérieure",newWindow:"Nouvelle fenêtre"}));
