//>>built
define("dijit/form/nls/da/validate",({invalidMessage:"Den angivne værdi er ugyldig.",missingMessage:"Værdien er påkrævet.",rangeMessage:"Værdien er uden for intervallet."}));
