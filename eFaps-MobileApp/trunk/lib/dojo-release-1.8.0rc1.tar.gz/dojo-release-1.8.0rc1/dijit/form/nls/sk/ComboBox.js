//>>built
define("dijit/form/nls/sk/ComboBox",({previousMessage:"Predchádzajúce možnosti",nextMessage:"Viac možností"}));
